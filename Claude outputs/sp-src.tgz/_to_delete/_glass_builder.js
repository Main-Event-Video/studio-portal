// ============================================================================
// GLASS — panes of lit glass in a bright room, the photograph mounted on the
// front one. Designed with Josh across frames 10, 17, 19, 23 and 24.
//
// TWO IDEAS CARRY THE WHOLE STYLE.
//
// 1. THE ROOM RECONFIGURES ITSELF AROUND EACH PHOTO'S SHAPE. A wide photo gets
//    one of two landscape rooms; a tall photo gets one of three portrait ones.
//    Nothing is designed per picture — the same rules run and the furniture
//    moves. That is the answer to a montage whose photos alternate 16:9 and
//    9:16, which is the case every other approach fell over on.
//
// 2. A PANE IN FRONT OF THE PHOTOGRAPH CARRIES NO PICTURE. Accent panes started
//    out holding crops of the same photo and every single time it read as the
//    same face three times across. In front, a pane is glass. Behind, or beside,
//    it may hold a picture — and then only a gentle one (see GLASS_MIN_VISIBLE).
//
// CROP SAFETY. An early version cropped accent panes to hardcoded percentages.
// On a tall photo of a standing child that isolated her torso and magnified it.
// The rule now: a pane may only carry a picture if it shows at least
// GLASS_MIN_VISIBLE of that picture — a gentle reframing, not a tight zoom — and
// the crop is TOP-anchored through coverBox like the rest of this engine, so it
// keeps heads. Anything tighter becomes plain glass. There is no way for this
// style to invent a close-up of a region nobody chose.
//
// (The sandbox prototype anchors tight crops on YuNet-detected eyes, which lets
// panes crop much harder in safety. That needs face detection in the render
// path, which does not exist yet — so this build simply does not take tight
// crops. See HANDOFF notes.)
//
// NOT RENDER-VERIFIED. y_rotation / perspective / backface behaviour is read off
// the Creatomate SDK types and previewed in the DOM simulator; no draft has been
// rendered. If the 3D properties misbehave, the panes fall flat and the style
// still reads, just without depth.
// ============================================================================

const GLASS_RECT = 'M 0 0 L 100 0 L 100 100 L 0 100 Z';

// A pane may carry a picture only if it shows at least this much of it. Below
// the line it becomes glass. 0.55 keeps a near-full reframing (the big side
// wings) and rejects a narrow blade or a letterbox band, which are exactly the
// shapes that produced the torso crop.
const GLASS_MIN_VISIBLE = 0.55;

// How much of the photograph a cover-fitted box actually shows.
function glassVisible(pw, ph, iw, ih) {
  if (!(pw > 0 && ph > 0 && iw > 0 && ih > 0)) return 0;
  const pAR = pw / ph, iAR = iw / ih;
  return Math.min(iAR / pAR, pAR / iAR);
}

// One pane. `p` is in FRACTIONS of the frame: {x,y,w,h} 0..1, plus ry (degrees),
// photo (bool), op, and dim (edge brightness 0..1).
function glassPane(p, it, W, H, S) {
  const px = (v) => `${(v * 100).toFixed(3)}%`;
  const boxW = p.w * W, boxH = p.h * H;

  // Can this pane hold the picture? Gentle crops only.
  const wantsPhoto = !!p.photo && !it.green;
  const gentle = wantsPhoto && glassVisible(boxW, boxH, it.w || 0, it.h || 0) >= GLASS_MIN_VISIBLE;

  const inner = [];
  if (gentle) {
    // coverBox sizes the image to its TRUE aspect and slides it by the photo's
    // framing bias — which defaults to TOP. Same head-keeping behaviour as every
    // other style in this engine.
    inner.push(applyPhotoColor({
      type: 'image', source: it.url, ...coverBox(it, boxW, boxH),
      ...(p.op != null ? { opacity: `${Math.round(p.op * 100)}%` } : {}),
    }, it));
  } else {
    // Plain glass: a faint pale fill. Also the fallback whenever a photo pane
    // would have had to crop too hard.
    const frost = p.frost == null ? 0.20 : p.frost;
    inner.push({
      type: 'shape', path: GLASS_RECT, width: '100%', height: '100%',
      x: '50%', y: '50%', x_anchor: '50%', y_anchor: '50%',
      fill_color: `rgba(255,255,255,${frost.toFixed(3)})`,
    });
  }

  // A soft diagonal sheen — the thing that stops a pane reading as a flat card.
  inner.push({
    type: 'shape', path: GLASS_RECT, width: '100%', height: '100%',
    x: '50%', y: '50%', x_anchor: '50%', y_anchor: '50%',
    fill_color: 'rgba(255,255,255,0.16)', blend_mode: 'screen', opacity: '55%',
  });

  // THE EDGE. This is what says "glass" once the photo is opaque. It is dimmed
  // where the pane crosses the photograph: at full strength a white line drawn
  // across a face reads as a scratch on the picture rather than as an edge.
  const dim = p.dim == null ? 1 : p.dim;
  inner.push({
    type: 'shape', path: GLASS_RECT, width: '100%', height: '100%',
    x: '50%', y: '50%', x_anchor: '50%', y_anchor: '50%',
    fill_color: 'rgba(0,0,0,0)',
    stroke_color: '#FFFFFF',
    stroke_width: `${Math.max(1, Math.round(H * 0.0022))} px`,
    opacity: `${Math.round(96 * dim)}%`,
  });

  const comp = {
    type: 'composition', clip: true,
    x: px(p.x + p.w / 2), y: px(p.y + p.h / 2),
    width: px(p.w), height: px(p.h),
    x_anchor: '50%', y_anchor: '50%',
    elements: inner,
  };
  if (p.ry) {
    comp.y_rotation = `${p.ry}°`;
    // Camera distance. Larger = flatter. Tied to frame width so the amount of
    // perspective does not change with output size.
    comp.perspective = Math.round(W * 0.85);
  }
  return comp;
}

// ---- LAYOUTS ---------------------------------------------------------------
// All coordinates are FRACTIONS of the frame, so the same numbers work at any
// output size. `photo: true` asks for the picture; the pane only gets it if the
// crop would be gentle (glassPane decides).
function glassLayout(it, variant) {
  const ar = (it.w > 0 && it.h > 0) ? it.w / it.h : 1.6;
  const land = ar >= 1;

  if (land) {
    const hw = 0.80, hh = Math.min(0.86, hw * (16 / 9) / ar * (9 / 16));
    const hHfrac = (hw * 1920 / ar) / 1080;      // hero height as a frame fraction
    const hgt = Math.min(0.88, hHfrac);
    const hx = (1 - hw) / 2, hy = (1 - hgt) / 2;
    const hero = { x: hx, y: hy, w: hw, h: hgt, ry: -3, photo: true, hero: true };

    if (variant % 2 === 0) {
      // L1 — THE RACK. Blades stacked down both margins, positioned by their
      // INNER edge so each clips the hero by a little and everything else lives
      // out in the margin. Placing them by their left edge instead is what once
      // put a blade squarely over a child's face.
      const inL = (over, w) => hx + over - w;
      const inR = (over) => hx + hw - over;
      return { kind: 'land', hero, panes: [
        { x: inL(0.031, 0.130), y: 0.00, w: 0.130, h: 1.00, ry: 20, frost: .22, dim: .30 },
        { x: inL(0.021, 0.104), y: 0.10, w: 0.104, h: 0.86, ry: 15, frost: .16, dim: .30 },
        { x: inL(0.039, 0.086), y: 0.22, w: 0.086, h: 0.65, ry: 10, photo: true, op: .55, dim: .30 },
        { x: inR(0.016), y: 0.14, w: 0.115, h: 0.76, ry: -12, frost: .18, dim: .30 },
        { x: inR(0.036), y: 0.06, w: 0.109, h: 0.93, ry: -17, photo: true, op: .45, dim: .30 },
      ] };
    }
    // L2 — HINGED WINGS. Panes fan from a centre hinge and recede behind the
    // hero, showing mostly lit edge. Quieter, and it reads as architecture.
    return { kind: 'land', hero, panes: [
      { x: -0.02, y: 0.02, w: 0.29, h: 0.96, ry: 44, frost: .16, behind: true },
      { x: 0.73, y: 0.02, w: 0.29, h: 0.96, ry: -44, frost: .16, behind: true },
      { x: 0.08, y: 0.11, w: 0.16, h: 0.78, ry: 30, photo: true, op: .34, behind: true },
      { x: 0.76, y: 0.11, w: 0.16, h: 0.78, ry: -30, photo: true, op: .34, behind: true },
      { x: hx - 0.078, y: 0.06, w: 0.104, h: 0.89, ry: 15, frost: .24, dim: .30 },
      { x: hx + hw - 0.026, y: 0.06, w: 0.104, h: 0.89, ry: -15, frost: .24, dim: .30 },
    ] };
  }

  // ---- PORTRAIT: three rooms --------------------------------------------
  const hgt = 0.92;
  const hwf = (hgt * 1080 * ar) / 1920;
  const v = variant % 3;

  if (v === 0) {
    // P1 — WINGS AND BLADES. The big side wings are the one place a picture can
    // sit at near-full size, so the right one carries it: a second view of the
    // same moment rather than a smaller copy of it.
    const hx = (1 - hwf) / 2, hy = (1 - hgt) / 2;
    return { kind: 'port', hero: { x: hx, y: hy, w: hwf, h: hgt, ry: -2, photo: true, hero: true }, panes: [
      { x: 0.06, y: 0.12, w: 0.245, h: 0.77, ry: 36, frost: .16, behind: true },
      { x: 0.695, y: 0.12, w: 0.245, h: 0.77, ry: -36, photo: true, op: .40, behind: true },
      { x: -0.005, y: 0.05, w: 0.172, h: 0.91, ry: 26, frost: .22, behind: true },
      { x: 0.833, y: 0.05, w: 0.172, h: 0.91, ry: -26, frost: .22, behind: true },
      { x: hx - 0.068, y: 0.00, w: 0.125, h: 1.00, ry: 14, frost: .24, dim: .30 },
      { x: hx + hwf - 0.057, y: 0.06, w: 0.109, h: 0.89, ry: -14, frost: .20, dim: .30 },
    ] };
  }

  if (v === 1) {
    // P2 — OFF-CENTRE LEFT, with a wide pane crossing behind and running toward
    // the right edge. The composition has a direction instead of being a mirror.
    const hx = 0.34 - hwf / 2, hy = (1 - hgt) / 2;
    return { kind: 'port', hero: { x: hx, y: hy, w: hwf, h: hgt, ry: -3, photo: true, hero: true }, panes: [
      { x: -0.04, y: 0.14, w: 0.156, h: 0.74, ry: 22, frost: .20, behind: true },
      // Held INSIDE the frame. When this ran off the right edge, the part still
      // on screen showed a shoulder rather than the subject it was aimed at.
      { x: hx + hwf - 0.021, y: 0.37, w: Math.min(0.49, 0.98 - (hx + hwf - 0.021)), h: 0.31, ry: -8, frost: .14, behind: true },
      { x: 0.80, y: 0.08, w: 0.177, h: 0.83, ry: -24, frost: .18, behind: true },
      { x: hx - 0.063, y: 0.02, w: 0.115, h: 0.96, ry: 13, frost: .24, dim: .30 },
      { x: hx + hwf - 0.052, y: 0.07, w: 0.104, h: 0.87, ry: -13, frost: .20, dim: .30 },
    ] };
  }

  // P3 — P2 handed the other way: hero right, wide pane left. So a run of tall
  // photos does not always lean the same direction.
  const hx = 0.66 - hwf / 2, hy = (1 - hgt) / 2;
  return { kind: 'port', hero: { x: hx, y: hy, w: hwf, h: hgt, ry: 3, photo: true, hero: true }, panes: [
    { x: 0.885, y: 0.14, w: 0.156, h: 0.74, ry: -22, frost: .20, behind: true },
    { x: 0.031, y: 0.37, w: Math.max(0.30, hx - 0.05), h: 0.31, ry: 8, frost: .14, behind: true },
    { x: 0.021, y: 0.08, w: 0.177, h: 0.83, ry: 24, frost: .18, behind: true },
    { x: hx + hwf - 0.052, y: 0.02, w: 0.115, h: 0.96, ry: -13, frost: .24, dim: .30 },
    { x: hx - 0.052, y: 0.07, w: 0.104, h: 0.87, ry: 13, frost: .20, dim: .30 },
  ] };
}

// Slow, unsynchronised drift. Movement is a SCALE and a POSITION shift, never a
// change of box size: the photo is cover-cropped, so resizing its box re-crops
// the picture every frame and the result reads as camera shake.
// EASING, and why it is not linear. A linear keyframe pair moves at a constant
// speed, which means it starts and stops instantly — at this slow a drift that
// snap is visible at both ends of every shot and reads as a jerk. 'sinusoid-in-
// out' eases away from rest and back into it, so a pane is never seen starting
// or stopping. It is the difference between a pane that glides and one that is
// switched on.
const GLASS_EASE = 'sinusoid-in-out';

function glassDrift(el, k, dur, isHero) {
  const dir = k % 2 ? -1 : 1;
  if (isHero) {
    el.x_scale = [{ time: 0, value: '100%', easing: GLASS_EASE }, { time: dur, value: '101.6%' }];
    el.y_scale = [{ time: 0, value: '100%', easing: GLASS_EASE }, { time: dur, value: '101.6%' }];
    return el;
  }
  const from = parseFloat(el.x), to = from + dir * 1.35;
  el.x = [{ time: 0, value: `${from.toFixed(3)}%`, easing: GLASS_EASE }, { time: dur, value: `${to.toFixed(3)}%` }];
  return el;
}

// Light beams: thin bright bars fanned from low centre, screen-blended, turning
// very slowly across the whole piece so the room is never quite still. They sit
// BEHIND the glass — in front they cut across the subject's face, which is
// backwards for a montage.
function glassBeams(S, total, W, H, track) {
  const defs = [
    [-116, 4, 82], [-124, 2, 58], [-133, 5, 72], [-147, 2, 48],
    [-64, 4, 82], [-56, 2, 58], [-47, 5, 72], [-33, 2, 48],
    [-97, 3, 54], [-83, 3, 54],
  ];
  return defs.map(([a, h, op], i) => ({
    name: `Beam-${i + 1}`, type: 'shape', track: track + i,
    time: 0, duration: +total.toFixed(3),
    path: GLASS_RECT,
    x: '50%', y: '96%', x_anchor: '0%', y_anchor: '50%',
    width: `${(72 + (i % 3) * 6)}%`, height: `${(h * 0.09).toFixed(2)}%`,
    fill_color: '#FFFFFF', blend_mode: 'screen',
    blur_radius: 3 + (i % 3) * 2, blur_mode: 'stack',
    opacity: `${op}%`,
    // Eased at the turn-around too, so the sway has no visible corner in it.
    z_rotation: [
      { time: 0, value: `${a - 1.6}°`, easing: 'sinusoid-in-out' },
      { time: +(total / 2).toFixed(3), value: `${a + 1.6}°`, easing: 'sinusoid-in-out' },
      { time: +total.toFixed(3), value: `${a - 1.6}°` },
    ],
  }));
}

function glassSource({ S, seq, title, subtitle, watermarkUrl, includeCards, width: W, height: H, background, perPhoto = null }) {
  const items = seq.filter((it) => it.type !== 'placeholder');
  const n = Math.max(1, items.length);
  const cardS = includeCards ? CARD_S : 0;
  const step = Math.max(1.4, perPhoto != null ? perPhoto : (Number(S.photoS) || 3.4));
  const fade = Math.min(1.0, step * 0.30);
  const total = cardS + n * step + cardS;

  const elements = slideFamilyShell({ S, background, total, includeCards, title, subtitle, watermarkUrl, H });
  glassBeams(S, total, W, H, 40).forEach((b) => elements.push(b));

  // Each variant is counted per SHAPE, so two wide photos in a row get different
  // rooms rather than the same one twice.
  const seen = { land: 0, port: 0 };

  items.forEach((it, i) => {
    const t0 = cardS + i * step;
    if (it.green) {
      elements.push({
        name: `Green-${i + 1}`, type: 'composition', track: 2, time: +t0.toFixed(3), duration: +step.toFixed(3),
        ...(i > 0 ? { animations: transitionIn(S, i) } : {}),
        elements: [{ type: 'shape', track: 1, path: GLASS_RECT, width: '100%', height: '100%', fill_color: CHROMA_GREEN }],
      });
      return;
    }
    const kind = (it.w > 0 && it.h > 0 && it.w < it.h) ? 'port' : 'land';
    const L = glassLayout(it, seen[kind]++);

    const inner = [];
    // Panes BEHIND the hero first, then the hero, then the blades in front.
    // Depth in this engine is order, not z, so this ordering IS the depth.
    L.panes.filter((p) => p.behind).forEach((p, k) => inner.push(glassDrift(glassPane(p, it, W, H, S), k, step, false)));
    inner.push(glassDrift(glassPane(L.hero, it, W, H, S), 0, step, true));
    L.panes.filter((p) => !p.behind).forEach((p, k) => inner.push(glassDrift(glassPane(p, it, W, H, S), k + 1, step, false)));

    elements.push({
      name: `Glass-${i + 1}`, type: 'composition', track: 2,
      time: +t0.toFixed(3), duration: +step.toFixed(3),
      ...(i > 0 ? { animations: transitionIn(S, i) } : {}),
      elements: inner,
    });
  });

  slideFamilyTail(elements, { includeCards, total, title, watermarkUrl, S, H });
  return { output_format: 'mp4', width: W, height: H, frame_rate: 30, elements };
}
