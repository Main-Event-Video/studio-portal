// Public, branded landing page for a shared/forwarded delivery. This is what a
// friend or vendor sees when they open a share link — Main Event Studio logo,
// the video (playable), and a Download button for finals. No login needed; the
// HMAC-signed token resolves to exactly ONE file and nothing else.
import Image from 'next/image';
import { headers } from 'next/headers';
import { resolveShareId } from '@/lib/shareLink';
import { createServiceClient } from '@/lib/supabaseAdmin';
import { getViewUrl } from '@/lib/r2';
import { sendCutOpenedNotice } from '@/lib/email';

// User agents we treat as bots/prefetchers/link-scanners (email security, social
// unfurlers) so their fetches don't count as a real "open". Intentionally does NOT
// match normal browsers (Chrome/Safari/Firefox/Edge/mobile).
const BOT_RE = /(bot|crawl|spider|slurp|facebookexternalhit|slackbot|twitterbot|whatsapp|telegrambot|discordbot|linkedinbot|embedly|redditbot|applebot|bingbot|googlebot|duckduckbot|yandexbot|mediapartners|proofpoint|mimecast|barracuda|skypeuripreview|preview|curl|wget|python|axios|node-fetch|go-http|headless|phantom|puppeteer|pingdom|uptimerobot|monitor|scanner)/i;

export const dynamic = 'force-dynamic';

// Link-preview card (email / iMessage / social). Personalized with the event name
// when we have it, otherwise a clean "A Main Event Studio Presentation", with the
// branded OG image — so a pasted link no longer unfurls as a generic "Client Portal".
export async function generateMetadata({ params }) {
  const base = process.env.NEXT_PUBLIC_SITE_URL || 'https://clients.maineventstudio.com';
  let title = 'A Main Event Studio Presentation';
  try {
    const db = createServiceClient();
    const mediaId = await resolveShareId(db, params?.sid);
    if (mediaId) {
      const { data: m } = await db.from('studio_media').select('client_id, kind').eq('id', mediaId).single();
      if (m && ['rough_cut', 'final'].includes(m.kind)) {
        const { data: c } = await db.from('studio_clients').select('display_name, event_type').eq('id', m.client_id).single();
        const nice = (c?.event_type && c.event_type.trim()) || (c?.display_name && c.display_name.trim());
        if (nice) title = nice;
      }
    }
  } catch { /* fall back to the generic branded title */ }
  const description = 'A Main Event Studio Presentation';
  const image = `${base}/og-share.png`;
  return {
    title,
    description,
    openGraph: { title, description, siteName: 'Main Event Studio', type: 'website', images: [{ url: image, width: 1200, height: 630 }] },
    twitter: { card: 'summary_large_image', title, description, images: [image] },
  };
}

export default async function SharePage({ params }) {
  const sid = params?.sid;
  const db = createServiceClient();
  const mediaId = await resolveShareId(db, sid);

  let m = null;
  if (mediaId) {
    const { data } = await db
      .from('studio_media')
      .select('id, filename, r2_key, kind, content_type, client_id')
      .eq('id', mediaId)
      .single();
    if (data && data.r2_key && ['rough_cut', 'final'].includes(data.kind)) m = data;
  }

  // Best-effort: notify the studio the FIRST time a real person opens this link.
  // Skipped for bots/prefetchers, and only fires once (guarded on opened_at).
  if (m) {
    try {
      const ua = headers().get('user-agent') || '';
      if (ua && !BOT_RE.test(ua)) {
        const { data: claimed } = await db
          .from('studio_media')
          .update({ opened_at: new Date().toISOString() })
          .eq('id', m.id)
          .is('opened_at', null)
          .select('id');
        if (Array.isArray(claimed) && claimed.length) {
          const { data: c } = await db.from('studio_clients').select('display_name').eq('id', m.client_id).single();
          await sendCutOpenedNotice({ filename: m.filename, kind: m.kind, clientName: c?.display_name || '' });
        }
      }
    } catch { /* tracking is best-effort — never block playback */ }
  }

  const viewUrl = m ? await getViewUrl(m.r2_key, 43200) : null;
  const isVideo = m && (m.content_type || '').startsWith('video');
  const canDownload = m && m.kind === 'final';

  return (
    <main className="wrap" style={{ maxWidth: 720, margin: '0 auto', padding: '28px 18px 48px' }}>
      <div style={{ textAlign: 'center', marginBottom: 12 }}>
        <Image src="/logo.png" alt="Main Event Studio" width={220} height={148} priority />
      </div>

      {!m ? (
        <div style={{ textAlign: 'center' }}>
          <h1 className="neon neon-blue" style={{ fontSize: 24, margin: '6px 0 8px' }}>Link not available</h1>
          <p style={{ color: 'var(--muted)' }}>This link is invalid or the file is no longer available.</p>
        </div>
      ) : (
        <>
          <p className="eyebrow" style={{ textAlign: 'center' }}>Shared with you</p>
          <h1 className="neon neon-blue" style={{ textAlign: 'center', fontSize: 22, margin: '4px 0 16px', wordBreak: 'break-word' }}>
            {m.filename}
          </h1>

          {isVideo ? (
            <video src={viewUrl} controls playsInline style={{ width: '100%', maxHeight: '70vh', borderRadius: 12, background: '#000', display: 'block' }} />
          ) : (
            <img src={viewUrl} alt={m.filename} style={{ width: '100%', borderRadius: 12, display: 'block' }} />
          )}

          {canDownload && (
            <div style={{ textAlign: 'center', marginTop: 18 }}>
              <a
                href={`/api/portal/share/${sid}?mode=download`}
                className="btn-primary"
                style={{ textDecoration: 'none', padding: '13px 30px', borderRadius: 10, fontWeight: 700, fontSize: 16, display: 'inline-block' }}
              >⤓ Download</a>
            </div>
          )}

          <p style={{ textAlign: 'center', color: 'var(--muted)', fontSize: 13, marginTop: 24 }}>
            Shared via{' '}
            <a href="https://www.maineventstudio.com" style={{ color: 'var(--blue, #3d7bff)', textDecoration: 'none' }}>
              Main Event Studio
            </a>
          </p>
        </>
      )}
    </main>
  );
}
