// GET /api/admin/montage/photos?clientId=...            → the client's full timeline
// GET /api/admin/montage/photos?montageId=...           → ONLY the photos in THAT
//   render, in play order, and (for Multi-Page styles) each photo's page + cell +
//   the cell's real aspect ratio, so the framing adjuster mirrors the actual boxes.
import { NextResponse } from 'next/server';
import { createServiceClient } from '@/lib/supabaseAdmin';
import { requireAdmin } from '@/lib/adminAuth';
import { getViewUrl, getDownloadUrl } from '@/lib/r2';
import { orderedClientMedia } from '@/lib/clientTimeline';
import { multiPageLayout, twoPanelLayout, STYLES } from '@/lib/montage';
import { importSeqMap } from '@/lib/importSeq';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// Compact copy of the render route's dimension probe (header bytes only, fully
// guarded) — the Multi-Page templates pick a cell shape from each photo's real
// aspect, so the adjuster needs the same dims to reproduce the boxes.
async function probeDims(url) {
  try {
    const sharp = (await import('sharp')).default;
    const res = await fetch(url, { headers: { Range: 'bytes=0-262143' } });
    if (!res.ok && res.status !== 206) return null;
    const buf = Buffer.from(await res.arrayBuffer());
    const md = await sharp(buf).metadata();
    if (md && md.width && md.height) {
      const rot = md.orientation >= 5 && md.orientation <= 8;
      return { w: rot ? md.height : md.width, h: rot ? md.width : md.height };
    }
  } catch { /* unknown → treat as landscape */ }
  return null;
}

export async function GET(request) {
  const auth = await requireAdmin(request);
  if (auth.error) return NextResponse.json({ error: auth.error }, { status: auth.status });

  const url = new URL(request.url);
  const clientId = url.searchParams.get('clientId');
  const montageId = url.searchParams.get('montageId');
  const db = createServiceClient();

  // ---- render-specific mode: only the photos in THIS render, with cell shapes ----
  if (montageId) {
    const { data: m, error: mErr } = await db
      .from('studio_montages')
      .select('id, client_id, style, params')
      .eq('id', montageId)
      .maybeSingle();
    if (mErr || !m) return NextResponse.json({ error: 'Render not found' }, { status: 404 });

    // Stable per-photo import numbers (001, 002 …) — permanent reference ids.
    const impSeq = await importSeqMap(db, m.client_id);

    const seq = Array.isArray(m.params?.renderSequence) ? m.params.renderSequence : null;
    // Old renders predate renderSequence → we can't know the exact subset; fall
    // back to the whole timeline so the adjuster still works (just not filtered).
    if (!seq) {
      const { media, error } = await orderedClientMedia(db, m.client_id, { imagesOnly: true });
      if (error) return NextResponse.json({ error: 'Could not load photos', detail: error.message }, { status: 500 });
      const photos = await Promise.all((media || []).slice(0, 500).map(async (mm, i) => ({
        index: i + 1, key: mm.r2_key, filename: mm.filename, album: mm.folder_path || null,
        importSeq: impSeq.byKey.get(mm.r2_key) ?? null,
        url: await getViewUrl(mm.r2_key, 3600), downloadUrl: await getDownloadUrl(mm.r2_key, mm.filename, 3600),
      })));
      return NextResponse.json({ photos, partial: true });
    }

    const keys = seq.filter((s) => s && s.type === 'photo' && s.r2_key).map((s) => s.r2_key);
    // Filenames for labels (one query, then map by r2_key).
    const { data: rows } = await db.from('studio_media')
      .select('r2_key, filename, folder_path').eq('client_id', m.client_id).in('r2_key', keys.length ? keys : ['__none__']);
    const meta = new Map((rows || []).map((r) => [r.r2_key, r]));

    // Build the play items in render order, probing each photo's real dims.
    const photoItems = await Promise.all(keys.map(async (k) => {
      const info = meta.get(k) || {};
      const u = await getViewUrl(k, 3600);
      const dims = await probeDims(u);
      return { type: 'photo', r2_key: k, url: u, filename: info.filename || null, album: info.folder_path || null, w: dims?.w || null, h: dims?.h || null };
    }));

    const st = STYLES[m.style] || {};
    let layout = null;
    if (st.twoPanel) {
      // Two Panel pairs photos (no green bookends); each gets a 16:9 or 9:16 frame.
      layout = twoPanelLayout({ items: photoItems }).slice(0, photoItems.length);
    } else if (st.multipage) {
      // Reproduce the render's grouping EXACTLY, including the green bookends that
      // occupy cells (greenScreen defaults on) so page/cell numbers line up.
      const green = m.params?.greenScreen !== false;
      const g = { type: 'photo', url: 'green', w: 1920, h: 1080 };
      const items = green ? [g, ...photoItems, g] : photoItems;
      const lay = multiPageLayout({ items, width: 1920, height: 1080, twoPanel: !!st.twoPanel });
      // lay is aligned to non-placeholder items in order; skip the leading green.
      layout = green ? lay.slice(1, 1 + photoItems.length) : lay.slice(0, photoItems.length);
    }
    // For single-photo cover styles, the framer preview box must match the shape the
    // photo is actually cropped into so the preview lines up with the export.
    //   • Duotone  → the 68%×90% hero box.
    //   • other cover-fill styles → the full 16:9 frame (preview default handles it).
    // MUST TRACK DUO_HERO in lib/montage.js. The hero grew from 58%x84% to
    // 68%x90% ("the main image needs to be large"), and if this number does not
    // move with it the framer shows the user a crop box that is not the crop
    // they will get.
    const focalAspect = st.duotone ? (0.68 * 1920) / (0.90 * 1080) : null;

    const photos = await Promise.all(photoItems.map(async (it, i) => ({
      index: i + 1,
      key: it.r2_key,
      filename: it.filename,
      album: it.album,
      importSeq: impSeq.byKey.get(it.r2_key) ?? null,
      url: it.url,
      downloadUrl: await getDownloadUrl(it.r2_key, it.filename || 'photo', 3600),
      ...(layout && layout[i]
        ? { page: layout[i].page, cell: layout[i].cell, cells: layout[i].cells, cellAspect: layout[i].cellAspect }
        : (focalAspect ? { cellAspect: focalAspect } : {})),
    })));
    return NextResponse.json({ photos, style: m.style, multipage: !!st.multipage });
  }

  // ---- default mode: the client's whole timeline (unchanged) ----
  if (!clientId) return NextResponse.json({ error: 'Missing clientId' }, { status: 400 });
  // Videos come back too now. Josh: "I need to be able to see where the video
  // goes." They are not IN the montage as footage, but their slot is — each one
  // becomes a chroma-green gap at exactly this position in the export — so
  // hiding them here hid the only thing that tells him where those gaps land.
  const { media: data, error } = await orderedClientMedia(db, clientId);
  if (error) return NextResponse.json({ error: 'Could not load photos', detail: error.message }, { status: 500 });

  // Stable per-photo import numbers (001, 002 …) — permanent reference ids.
  const impSeq = await importSeqMap(db, clientId);

  // THE PHOTO NUMBER MUST NOT COUNT VIDEOS. `index` is not decoration — it is the
  // key the montage's photo selection is written in ("1-20,25"), so a video
  // taking a number would silently shift every selection past it. Photos keep an
  // unbroken 1..N; a video carries no number at all.
  let photoNo = 0;
  const photos = await Promise.all(
    (data || []).slice(0, 500).map(async (m, i) => {
      const isVideo = !(m.content_type || '').startsWith('image/');
      if (!isVideo) photoNo += 1;
      return {
      index: isVideo ? null : photoNo,
      video: isVideo,
      // Position in the client's timeline. The admin keeps photos and videos in
      // SEPARATE lists (see loadProjPhotos) so nothing that counts photos is
      // disturbed, and merges them by this for display only.
      ord: i,
      id: m.id,
      key: m.r2_key,
      filename: m.filename,
      album: m.folder_path || null,
      importSeq: impSeq.byKey.get(m.r2_key) ?? null,
      // The client's own crop, if they made one. The strip SHOWS the cropped
      // version — it is what the montage will use — and carries the flag so the
      // tile can badge it and the editor can offer the full frame back.
      clientCrop: !isVideo && !!m.crop_key,
      cropRatio: (m.crop_rect && m.crop_rect.ratio) || null,
      url: await getViewUrl((!isVideo && m.crop_key) || m.r2_key, 3600),
      originalUrl: (!isVideo && m.crop_key) ? await getViewUrl(m.r2_key, 3600) : null,
      downloadUrl: await getDownloadUrl(m.r2_key, m.filename, 3600),
      };
    })
  );
  return NextResponse.json({ photos });
}
