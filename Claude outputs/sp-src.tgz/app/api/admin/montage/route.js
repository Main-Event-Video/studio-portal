// POST /api/admin/montage  { clientId, title, subtitle, watermark }
//   → builds the render from the client's uploaded PHOTOS (in folder+number
//     order), submits to Creatomate, tracks it in studio_montages.
// GET  /api/admin/montage
//   → list renders (admin panel status list) with playable URLs.
import { NextResponse } from 'next/server';
import { createServiceClient } from '@/lib/supabaseAdmin';
import { requireAdmin } from '@/lib/adminAuth';
import { getViewUrl, getDownloadUrl, resolveBackground, BACKGROUND_PREFIX } from '@/lib/r2';
import { buildMontageSource, STYLES, parsePhotoSpec, styleNeedsDims, styleNeedsFaces, draftScaleFor, normalizeKeyColor, keyAssetFor } from '@/lib/montage';
import { createRender } from '@/lib/creatomate';
import { orderedClientTimeline } from '@/lib/clientTimeline';
import { isHeic } from '@/lib/heic';
import { resolveBorder, borderIsOn, normalizeStyleBorder } from '@/lib/photoBorder';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const MAX_PHOTOS = 100; // spine cap: keeps renders + credits sane

// Read a photo's real pixel dimensions from just its header bytes, so the
// tiled/print styles can give a portrait its own tall cell (native shape). Range
// fetch keeps it cheap (no full download); sharp parses the header; EXIF
// orientation 5–8 means the displayed image is rotated 90°, so its aspect swaps.
// Fully guarded: any failure (sharp missing, truncated header, odd format) just
// returns null and the style falls back to treating the photo as landscape.
async function probeDims(url) {
  try {
    const sharp = (await import('sharp')).default;
    const res = await fetch(url, { headers: { Range: 'bytes=0-262143' } });
    if (!res.ok && res.status !== 206) return null;
    const buf = Buffer.from(await res.arrayBuffer());
    const md = await sharp(buf).metadata();
    if (md && md.width && md.height) {
      const rot = md.orientation >= 5 && md.orientation <= 8;
      return { w: rot ? md.height : md.width, h: rot ? md.width : md.height };
    }
  } catch { /* unknown → caller defaults to landscape */ }
  return null;
}

// WHY THIS WRAPPER EXISTS. Every EXPECTED failure in here returns
// NextResponse.json({ error }), and the admin shows that message. But an
// UNEXPECTED throw had nothing catching it, so Next returned a bare 500 with no
// body and the admin could only say "Request failed (500)" — which is exactly
// what Josh hit trying to test the neon, and it left both of us guessing at a
// stack trace neither of us could see.
//
// Now the real message comes back. It is admin-only behind requireAdmin, so
// there is no one to leak an internal detail to, and a name plus a message is
// the difference between one round trip and five.
export async function POST(request) {
  try {
    return await postMontage(request);
  } catch (e) {
    const detail = e && e.message ? String(e.message) : String(e);
    console.error('[montage POST] uncaught', e);
    return NextResponse.json({
      error: `Render request failed: ${detail}`,
      where: (e && e.stack ? String(e.stack).split('\n').slice(0, 4).join(' | ') : null),
    }, { status: 500 });
  }
}

async function postMontage(request) {
  const auth = await requireAdmin(request);
  if (auth.error) return NextResponse.json({ error: auth.error }, { status: auth.status });

  let body;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
  }
  const { clientId, title, subtitle, watermark = true, style = 'hollywood', photoSeconds = null, totalSeconds = null, adjustments = {}, photoSpec = null, album = null, includeCards = true, videoPlaceholders = true, greenScreen = true, background = null, mpTransition = null, mpStagger = null, mpHold = null, mpSpeed = null, duoPalette = null, duoTreatment = null, glassLight = true, glassRefl = null, draftScale = null, fbAtmosphere = null, fbFrameW = null, fbFrameColor = null, keyColor = null, styleBorder = null, atmo = null, neon = null, stills = null } = body || {};
  // "Add background" control: keyable green-screen (default) or an imported image
  // + tint/opacity. Sanitised to a small known shape; null = the style's own bg.
  // Built-in animated textures live in public/backgrounds/<name>.jpg.
  const TEXTURES = { soft_focus: 1, linen: 1, gradient: 1 };
  const bgControl = (background && typeof background === 'object')
    ? {
        green: !!background.green,
        // Blurred blow-up of EACH photo (the Framed Box bed, offered to every
        // style that can show a backdrop). Not a single layer like the others —
        // the engine builds it as a per-shot sequence.
        photoBlur: !!background.photoBlur,
        // built-in texture (name only; URL resolved at render time from siteUrl)
        texture: (background.texture && TEXTURES[background.texture]) ? String(background.texture) : null,
        animated: background.animated !== false,   // textures drift by default
        url: background.url ? String(background.url) : null,
        // IMPORTED background from the studio library. We store the r2_key, never
        // a URL: presigned URLs expire, and Export Full Rez re-renders from these
        // stored params days later. The key is turned into a fresh presigned URL
        // at render time by resolveBackground() — same rule as renderSequence.
        r2_key: (background.r2_key && String(background.r2_key).startsWith(BACKGROUND_PREFIX))
          ? String(background.r2_key) : null,
        kind: background.kind === 'video' ? 'video' : (background.kind === 'image' ? 'image' : null),
        // Length of the backdrop CLIP, read in the browser when it was picked.
        // Lets the engine lay overlapping copies and cross-dissolve each wrap,
        // instead of hard-looping a clip that was never built to loop. Absent =
        // fall back to a plain loop.
        clipS: (Number.isFinite(Number(background.clipS)) && Number(background.clipS) > 0)
          ? Number(background.clipS) : null,
        tint: background.tint ? String(background.tint) : null,
        opacity: background.opacity ? String(background.opacity) : null,
        blur: Number.isFinite(Number(background.blur)) ? Number(background.blur) : null,
      }
    : null;
  if (photoSeconds != null && !(Number(photoSeconds) >= 1 && Number(photoSeconds) <= 10)) {
    return NextResponse.json({ error: 'photoSeconds must be 1–10' }, { status: 400 });
  }
  // Total-length mode: photos cycle to fit this many seconds (overrides seconds/photo).
  if (totalSeconds != null && !(Number(totalSeconds) >= 3 && Number(totalSeconds) <= 1800)) {
    return NextResponse.json({ error: 'totalSeconds must be 3–1800' }, { status: 400 });
  }
  if (!clientId || !title) {
    return NextResponse.json({ error: 'clientId and title are required' }, { status: 400 });
  }
  if (!STYLES[style]) {
    return NextResponse.json({ error: 'Unknown style' }, { status: 400 });
  }

  const db = createServiceClient();
  const { data: client, error: cErr } = await db
    .from('studio_clients')
    .select('id, display_name, archived, photo_edits')
    .eq('id', clientId)
    .single();
  if (cErr || !client) return NextResponse.json({ error: 'Client not found' }, { status: 404 });
  if (client.archived) return NextResponse.json({ error: 'That client is archived' }, { status: 400 });

  // Per-client Photo Editor edits (from studio_clients.photo_edits) — applied to
  // EVERY render for this client, whatever style is chosen. Default framing is
  // TOP (keep heads); a per-render Fix-framing adjustment still overrides it.
  const pe = client.photo_edits && typeof client.photo_edits === 'object' ? client.photo_edits : {};
  const pePhotos = pe.photos && typeof pe.photos === 'object' ? pe.photos : {};
  // A photo's album decides which global border applies to it, so the r2_key ->
  // album map has to be built before any photo object is made.
  const albumByKey = new Map();
  // The montage-wide border override. null means "use the Edit Photos borders",
  // which is the default and leaves every existing render behaving as before.
  // THE KEY COLOUR, resolved HERE and not further down. It was originally
  // declared next to the green bookend it feeds, several hundred lines below —
  // but params.keyColor is written into the database insert LONG BEFORE that, in
  // an outer scope, so every render since threw "KEY is not defined" before it
  // reached Creatomate. Parse checks cannot see this; only running it can.
  // Anything the params snapshot needs has to be resolved up here with it.
  const KEY = normalizeKeyColor(keyColor);
  const SB = normalizeStyleBorder(styleBorder);
  // MEVID STILLS segment settings (9/9), snapshotted into params so Export Full
  // Rez replays the same picks and screens.
  const STILLS = cleanStills(stills);
  // Universal overlays: dust + light leaks, and neon squiggles. Percentages,
  // clamped here so a hand-made request cannot ask for something silly.
  const pct = (v, d) => (Number.isFinite(Number(v)) ? Math.max(0, Math.min(300, Number(v))) : d);
  const ATMO = (atmo && typeof atmo === 'object' && atmo.on)
    ? { on: true, intensity: pct(atmo.intensity, 100), dust: pct(atmo.dust, 100), leak: pct(atmo.leak, 100) }
    : null;
  const NEON = (neon && typeof neon === 'object' && neon.on)
    ? { on: true, intensity: pct(neon.intensity, 100),
        // Tube thickness, its own dial on top of intensity. Missing/null means
        // 100 — Number(null) is 0, so pct() alone would turn "not set" into a
        // hairline.
        thickness: (neon.thickness === null || neon.thickness === undefined || neon.thickness === '') ? 100 : pct(neon.thickness, 100),
        // One colour, or several to alternate between. Capped at six so a
        // hand-made request cannot make the cycle meaningless.
        colors: Array.isArray(neon.colors)
          ? neon.colors.filter((c) => typeof c === 'string' && /^#[0-9A-Fa-f]{6}$/.test(c))
            .slice(0, 6).map((c) => c.toUpperCase())
          : [],
        color: (typeof neon.color === 'string' && /^#[0-9A-Fa-f]{6}$/.test(neon.color)) ? neon.color.toUpperCase() : '#00E5FF' }
    : null;
  const editFor = (k) => {
    const e = pePhotos[k] || {};
    return {
      anchor: ['top', 'center', 'bottom'].includes(e.anchor) ? e.anchor : 'top',
      // null = unset (let the style default decide: Party 2 fills+drifts, others
      // fit). An explicit 'fit'/'fill' from the editor always wins in montage.js.
      fit: e.fit === 'fill' ? 'fill' : e.fit === 'fit' ? 'fit' : null,
      size: Math.min(140, Math.max(60, Number(e.size) || 100)),
      removed: !!e.removed,
      colorCorrect: !!e.colorCorrect,
      mode: ['color', 'bw', 'sepia'].includes(e.mode) ? e.mode : 'color',
      contrast: Number.isFinite(Number(e.contrast)) ? Math.min(200, Math.max(50, Math.round(Number(e.contrast)))) : 100,
      saturation: Number.isFinite(Number(e.saturation)) ? Math.min(200, Math.max(0, Math.round(Number(e.saturation)))) : 100,
      posX: Number.isFinite(Number(e.posX)) ? Number(e.posX) : null,
      posY: Number.isFinite(Number(e.posY)) ? Number(e.posY) : null,
      // Josh's per-montage escape from a client's crop, for a look that needs the
      // full frame. Deliberately NOT a change to what the client saved.
      useOriginal: e.useOriginal === true,
      // Album border vs per-photo border, most recently set one wins. Resolved
      // here (not in the engine) so the stored render snapshot carries the border
      // that was actually chosen at this moment — an Export Final months later
      // reproduces THIS draft even if the album's border has changed since.
      // Album border vs per-photo border, most recently set one wins — UNLESS
      // the style panel set one, which outranks both (Josh: "i want the Choose
      // Style to override the Edit photos border"). Resolved here, not in the
      // engine, so the stored render snapshot carries the border that was
      // actually chosen at this moment: an Export Final months later reproduces
      // THIS draft even if the album's border has changed since.
      border: resolveBorder(pe, k, albumByKey.get(k) || null, SB),
    };
  };
  const photoObj = (k) => {
    const e = editFor(k);
    const adj = adjustments && adjustments[k] != null ? adjustments[k] : undefined; // number 0 (slider top) must survive
    // THE CLIENT'S CROP, and Josh's per-montage escape from it. When the client
    // has cropped a photo the montage uses their version — "the montage knows to
    // keep it as is" — unless this montage says otherwise. The override lives in
    // the per-montage edit, so switching back to the full frame for one look
    // never touches what the client saved.
    const cropKey = cropByKey.get(k) || null;
    const useCrop = cropKey && e.useOriginal !== true;
    return { type: 'photo', r2_key: useCrop ? cropKey : k, sourceKey: k, clientCropped: !!cropKey, usingCrop: !!useCrop,
      framing: adj != null ? adj : e.anchor, fit: e.fit, size: e.size, colorCorrect: e.colorCorrect, mode: e.mode, contrast: e.contrast, saturation: e.saturation, posX: e.posX, posY: e.posY, border: borderIsOn(e.border) ? e.border : null };
  };

  // Full timeline (photos + videos) in play order. Photos define the 1..N
  // numbering the admin strip uses; each video becomes a green-screen placeholder
  // the editor keys their real clip into.
  const { items: timelineItems, error: mErr } = await orderedClientTimeline(db, clientId);
  if (mErr) return NextResponse.json({ error: 'Could not load media', detail: mErr.message }, { status: 500 });
  for (const m of timelineItems || []) albumByKey.set(m.r2_key, m.folder_path || null);
  // Which photos the client cropped, and where that crop lives.
  const cropByKey = new Map();
  for (const m of timelineItems || []) if (m.crop_key) cropByKey.set(m.r2_key, m.crop_key);
  const photosAll = (timelineItems || []).filter((m) => (m.content_type || '').startsWith('image/') && !isHeic({ filename: m.filename, contentType: m.content_type }));
  if (photosAll.length < 1) {
    return NextResponse.json(
      { error: 'This client has no photo uploads yet. Upload photos first.' },
      { status: 400 }
    );
  }

  // Which photos this segment uses (blank spec = all), 1-based, in play order.
  const indexes = parsePhotoSpec(photoSpec, photosAll.length);
  const selected = new Set(indexes);
  const ascending = indexes.every((v, i) => i === 0 || v > indexes[i - 1]);

  // Build the play sequence. When placeholders are on AND the selection is in
  // natural order, walk the timeline and drop a green gap at each video slot
  // (trimming leading/trailing gaps). Otherwise fall back to the exact spec
  // order with photos only (preserves the reorder-spec behavior).
  const wantGaps = videoPlaceholders !== false && ascending && indexes.length > 0;
  let sequence;
  if (wantGaps) {
    const numByKey = new Map();
    photosAll.forEach((p, i) => numByKey.set(p.r2_key, i + 1));
    sequence = [];
    for (const it of timelineItems) {
      const ct = it.content_type || '';
      if (ct.startsWith('image/')) {
        const num = numByKey.get(it.r2_key);
        if (selected.has(num) && !editFor(it.r2_key).removed) sequence.push(photoObj(it.r2_key));
      } else if (ct.startsWith('video/')) {
        sequence.push({ type: 'placeholder', name: it.filename });
      }
    }
    while (sequence.length && sequence[0].type === 'placeholder') sequence.shift();
    while (sequence.length && sequence[sequence.length - 1].type === 'placeholder') sequence.pop();
  } else {
    sequence = indexes.map((i) => photosAll[i - 1]).filter(Boolean)
      .filter((m) => !editFor(m.r2_key).removed)
      .map((m) => photoObj(m.r2_key));
  }

  const photoItems = sequence.filter((s) => s.type === 'photo');
  const gapCount = sequence.length - photoItems.length;
  if (photoItems.length < 1) {
    return NextResponse.json(
      { error: `Your photo selection didn't match any of this client's ${photosAll.length} photos — check the numbers.` },
      { status: 400 }
    );
  }
  if (photoItems.length > MAX_PHOTOS) {
    return NextResponse.json(
      { error: `This segment selects ${photoItems.length} photos; the max per render is ${MAX_PHOTOS}. Split it into more segments.` },
      { status: 400 }
    );
  }

  // Stable per-client render NUMBER, stamped at creation so it never shifts or
  // recycles when other renders are removed. The old number was recomputed by
  // position on every read, so deleting/re-rendering reshuffled it and exports
  // collected duplicate ###'s. next = 1 + the highest number already in use.
  let nextSeq = 1;
  try {
    const { data: prior } = await db.from('studio_montages').select('params').eq('client_id', client.id);
    // Only PRIMARY renders (not Export re-renders) consume numbers, so exports
    // sharing a draft's number can't inflate the next draft's number.
    let maxStored = 0, primaryCount = 0;
    for (const p of prior || []) {
      if (p?.params?.rerenderOf) continue;
      primaryCount++;
      const s = Number(p?.params?.seq); if (Number.isFinite(s)) maxStored = Math.max(maxStored, s);
    }
    nextSeq = Math.max(maxStored, primaryCount) + 1;
  } catch { /* leave at 1; GET keeps a positional fallback for un-stamped rows */ }

  // Track the job first so the webhook has a row to update.
  const { data: row, error: insErr } = await db
    .from('studio_montages')
    .insert({
      client_id: client.id,
      style,
      title,
      subtitle: subtitle || null,
      status: 'queued',
      photo_count: photoItems.length,
      watermarked: !!watermark,
      params: {
        seq: nextSeq,      // permanent studio render number (never recycled)
        photoSeconds: photoSeconds ? Number(photoSeconds) : null,
        totalSeconds: totalSeconds ? Number(totalSeconds) : null,
        adjustments: adjustments && typeof adjustments === 'object' ? adjustments : {},
        // Photo selection for this segment: the raw expression (for display) and
        // the resolved 1-based positions (for exact re-renders). Blank = all.
        photoSpec: photoSpec ? String(photoSpec).trim() : null,
        album: album ? String(album).trim() : null,
        photoIndexes: indexes,
        includeCards: includeCards !== false,
        videoPlaceholders: videoPlaceholders !== false,
        greenScreen: greenScreen !== false,
        // SNAPSHOTTED so Export Full Rez re-renders in the same colour, and so a
        // montage keyed green last month stays green when it is re-exported.
        keyColor: KEY,
        // Kept for display only — the resolved border is already baked into
        // renderSequence, so finalize needs nothing from this.
        styleBorder: (styleBorder && typeof styleBorder === 'object') ? styleBorder : null,
        atmo: ATMO, neon: NEON,   // snapshotted so Export Full Rez matches
        videoGaps: gapCount,
        colorCorrect: !!pe.colorCorrect,
        background: bgControl,   // "Add background" control, so Export Final reuses it
        stills: STILLS,          // MEvid Stills picks/screens/mode — replayed by Export Final
        // Multi Page motion options (transition + rhythm), so a re-render matches.
        mpTransition: mpTransition || null,
        mpStagger: Number.isFinite(Number(mpStagger)) ? Number(mpStagger) : null,
        mpHold: Number.isFinite(Number(mpHold)) ? Number(mpHold) : null,
        mpSpeed: Number.isFinite(Number(mpSpeed)) ? Number(mpSpeed) : null,
        // Duotone background colour, snapshotted so Export Final matches the draft.
        duoPalette: duoPalette || null,
        duoTreatment: duoTreatment || null,
        glassLight: glassLight !== false,   // Glass: light beams on/off
        glassRefl,                          // Glass: reflections (null = on; false only to speed a motion-only draft)
        // Framed Box. Snapshotted like everything else here so Export Final
        // reproduces THIS draft; sanitised at the boundary rather than trusted.
        // fbFrameW keeps null when unset — 0 is a real setting (no frame) and
        // Number(null) === 0, so a bare isFinite check would turn "not set" into
        // "off". That trap has bitten this codebase twice.
        fbAtmosphere: fbAtmosphere !== false,
        fbFrameW: (fbFrameW === null || fbFrameW === undefined || fbFrameW === '' || !Number.isFinite(Number(fbFrameW)))
          ? null : Math.max(0, Math.min(2.4, Number(fbFrameW))),
        fbFrameColor: (typeof fbFrameColor === 'string' && /^#[0-9a-fA-F]{6}$/.test(fbFrameColor))
          ? fbFrameColor.toUpperCase() : null,

        // Fully-resolved play sequence (r2_keys + each photo's edits AT THIS
        // MOMENT, placeholder names) — the snapshot the "Export Final" re-render
        // rebuilds from, so a final reproduces THIS draft exactly even if the
        // client's photo edits change afterward. URLs are NOT stored (they
        // expire); finalize re-presigns from the r2_keys.
        renderSequence: sequence,
      },
    })
    .select('id')
    .single();
  if (insErr) return NextResponse.json({ error: 'Could not track render', detail: insErr.message }, { status: 500 });

  try {
    const siteUrl = process.env.NEXT_PUBLIC_SITE_URL;
    // Only the tiled/print styles need each photo's real shape (portrait vs
    // landscape) to lay out native-aspect cells; the one-at-a-time styles always
    // cover-fill, so we skip the probe for them (keeps those renders fast).
    const st = STYLES[style] || {};
    // Styles that lay out by each photo's real aspect need the pixel dims probed:
    // tiled/print walls, Epic, plus Photo Drop (native-aspect card) and Story
    // Builder (aspect-aware fan). Without this, aspect defaults to square and
    // Photo Drop squishes landscapes.
    // A border has to know where the picture's edge IS. Josh chose "hug the actual
    // photo edge", and on a Fit photo that edge is the letterbox rect, which is
    // only computable from the photo's real pixel shape. So a border forces the
    // dimension probe on styles that would otherwise skip it. It costs a header
    // range-fetch per photo and only when a border is actually switched on.
    const anyBorder = sequence.some((s) => s.type === 'photo' && borderIsOn(s.border));
    // Neon too: the light traces the picture's own rect, and on a Fit photo
    // that rect is only knowable from the real pixel shape. Without dims the
    // photo goes out as a bare image and gets no light at all.
    const needsDims = styleNeedsDims(st) || anyBorder || !!NEON;
    // FACE DATA for Glass's accent crops. One query for the whole sequence, not
    // one per photo, and only for the style that uses it. A photo with no row —
    // or one the detection job has not reached yet — simply has no faces, and
    // every accent pane on it becomes plain glass. That is the intended
    // degradation, so a missing backfill is a look, never a bad crop.
    const facesByKey = new Map();
    if (styleNeedsFaces(st)) {
      const keys = sequence.filter((s) => s.type === 'photo' && s.r2_key).map((s) => s.r2_key);
      if (keys.length) {
        const { data: fr } = await db.from('studio_media')
          .select('r2_key, faces').eq('client_id', client.id).in('r2_key', keys);
        for (const r of (fr || [])) if (Array.isArray(r.faces)) facesByKey.set(r.r2_key, r.faces);
      }
    }
    // Long-lived presigned URLs — Creatomate fetches these while rendering.
    // Placeholders carry only a name (a green gap the editor keys their clip into).
    const photoItemsBuilt = await Promise.all(
      sequence.map(async (s) => {
        if (s.type !== 'photo') return { type: 'placeholder', name: s.name };
        const url = await getViewUrl(s.r2_key, 21600);
        const dims = needsDims ? await probeDims(url) : null;
        const it = { type: 'photo', url, sourceKey: s.sourceKey || s.r2_key, framing: s.framing, fit: s.fit, size: s.size, colorCorrect: s.colorCorrect, mode: s.mode, contrast: s.contrast, saturation: s.saturation, posX: s.posX, posY: s.posY, border: s.border || null, w: dims?.w || null, h: dims?.h || null, faces: facesByKey.get(s.r2_key) || null };
        // MEvid Stills derivatives (cut-out / watercolor), presigned for this render.
        if (st.stills) await attachStillsDerivatives(it, pePhotos);
        return it;
      })
    );

    // GREEN SCREEN as a real PHOTO (Josh): when on, a broadcast-green frame is
    // injected as the first AND last item, so every style just treats it like a
    // photo — full-frame green on the slideshows, a green print in Polaroid, a
    // green cell in the walls. It drops in like any photo (no overlay covering the
    // opening), and the editor `green` flag keeps it keyable (duotone renders it
    // pure, not tinted). public/green.png is the asset.
    // The backdrop colour is a per-montage setting now (a key cannot tell
    // backdrop green from green inside a photograph). The bookend is a real
    // photo item, so it needs the matching solid asset, not just the hex.
    const greenItem = { type: 'photo', green: true, url: `${siteUrl}${keyAssetFor(KEY)}`, fit: 'fill', w: 1920, h: 1080 };
    const items = (greenScreen !== false)
      ? [greenItem, ...photoItemsBuilt, greenItem]
      : photoItemsBuilt;

    // Presign the imported background (if any) for THIS render. bgControl keeps
    // the r2_key for the params snapshot; bgResolved carries the live URL.
    const bgResolved = await resolveBackground(bgControl);

    const source = buildMontageSource({
      items,
      style,
      photoSeconds: photoSeconds ? Number(photoSeconds) : null,
      totalSeconds: totalSeconds ? Number(totalSeconds) : null,
      includeCards: includeCards !== false,
      greenBookends: false,   // green is now an injected photo, not an overlay
      title: String(title).toUpperCase(),
      subtitle: subtitle ? String(subtitle).toUpperCase() : null,
      watermarkUrl: watermark ? `${siteUrl}/watermark.png` : null,
      assetBase: siteUrl || null,   // for collage light-leak overlays (public/overlays/*)
      background: (bgControl && bgControl.texture)
        ? { ...bgControl, textureUrl: `${siteUrl}/backgrounds/${bgControl.texture}.jpg` }
        : bgResolved,               // green / texture / pasted url / imported library image or video
      keyColor: KEY,                              // backdrop colour to key against
      atmosphereOpts: ATMO,                       // dust + light leaks, any style
      // Framed Box scales its OWN married atmosphere by the same numbers, so one
      // set of sliders drives both the flat overlay and the married version.
      atmoOpts: (atmo && typeof atmo === 'object')
        ? { intensity: pct(atmo.intensity, 100), dust: pct(atmo.dust, 100), leak: pct(atmo.leak, 100) } : null,
      neonOpts: NEON,                             // neon squiggles, any style
      mpTransition, mpStagger, mpHold, mpSpeed,   // Multi Page motion options
      duoPalette, duoTreatment,                   // Duotone background colour
      glassLight: glassLight !== false,           // Glass: the spotlight beams
      // GLASS REFLECTIONS are the expensive layer — they duplicate every pane's
      // body — but skipping them on drafts was the wrong default and I should
      // not have shipped it. Josh on render V7: "there is no reflection in the
      // panels. need to get those back." A draft you cannot judge is not a
      // faster draft, it is a wasted one: measured against the v6 reference the
      // reflection-free build has 2,587 detectable pane edges against 12,472,
      // so nearly all of the glass structure was missing from the thing he was
      // being asked to approve.
      //
      // Reflections are ON everywhere now. The switch stays, because there IS a
      // case for it — iterating purely on motion or timing, where the panes'
      // material does not matter and the render time does — but it has to be
      // asked for explicitly rather than being the quiet default.
      glassRefl: glassRefl !== false,
      atmosphere: fbAtmosphere !== false,
      frameW: (fbFrameW === null || fbFrameW === undefined || fbFrameW === '' || !Number.isFinite(Number(fbFrameW)))
        ? null : Math.max(0, Math.min(2.4, Number(fbFrameW))),
      frameColor: (typeof fbFrameColor === 'string' && /^#[0-9a-fA-F]{6}$/.test(fbFrameColor)) ? fbFrameColor : null,
      stillsOpts: STILLS,                         // MEvid Stills
    });

    const render = await createRender({
      source,
      webhookUrl: `${siteUrl}/api/webhooks/creatomate`,
      metadata: row.id, // webhook looks the row up by this
      // Watermarked = a DRAFT (checking motion/framing), so render at half
      // resolution → ~1/4 the Creatomate credits. Un-watermarked finals stay
      // full-res. Big saver while iterating (see credit formula in creatomate.js).
      // Drafts render small; the full export never does. Per style, because
      // Glass is far heavier than the rest — see draftScaleFor. An explicit
      // draftScale in the request overrides, for the case where the fine
      // material is what needs judging and the wait is worth it.
      renderScale: watermark ? (Number(draftScale) > 0 ? Math.min(1, Number(draftScale)) : draftScaleFor(style)) : null,
    });

    await db
      .from('studio_montages')
      .update({ status: 'rendering', render_id: render.id, updated_at: new Date().toISOString() })
      .eq('id', row.id);

    // WHAT WAS ACTUALLY BUILT. Josh turned neon on, the render came back and
    // there was none — and there was no way to tell whether the setting had not
    // reached the engine, or had reached it and Creatomate ignored the shapes.
    // Those are completely different bugs and guessing between them costs a
    // render each time. Counting the emitted elements separates them in one go:
    // a zero here means it never got built, a number here means it was built and
    // the renderer dropped it.
    const built = (() => {
      const n = (re) => source.elements.filter((e) => re.test(e.name || '')).length;
      return { elements: source.elements.length, neon: n(/^OvlNeon/), dust: n(/^OvlDust/), leak: n(/^OvlLeak/) };
    })();
    return NextResponse.json({ ok: true, montageId: row.id, renderId: render.id, built });
  } catch (e) {
    await db
      .from('studio_montages')
      .update({ status: 'failed', error: String(e.message || e).slice(0, 500), updated_at: new Date().toISOString() })
      .eq('id', row.id);
    return NextResponse.json({ error: 'Render failed to start', detail: e.message }, { status: 500 });
  }
}

export async function GET(request) {
  const auth = await requireAdmin(request);
  if (auth.error) return NextResponse.json({ error: auth.error }, { status: auth.status });

  const db = createServiceClient();
  const { data, error } = await db
    .from('studio_montages')
    .select('id, client_id, style, title, subtitle, status, video_url, r2_key, error, photo_count, watermarked, params, created_at, studio_clients(display_name, last_name)')
    .order('created_at', { ascending: false })
    .limit(500);   // was 25 (GLOBAL across all clients) — a busy day of rendering pushed older drafts out of view and broke per-client numbering. 500 keeps everyone's renders visible.
  if (error) return NextResponse.json({ error: 'Could not load renders', detail: error.message }, { status: 500 });

  // Studio file-naming: a stable per-client sequence number (oldest render = 001)
  // — shown on the card AND used as the filename prefix so a draft maps back to a
  // card — plus a version that bumps for re-renders of the same client + style +
  // range + album.
  const seqMap = new Map(), verMap = new Map(), perVariant = {};
  // Group by client so each client numbers independently.
  const byClient = {};
  for (const r of (data || [])) { const cid = r.client_id || ''; (byClient[cid] = byClient[cid] || []).push(r); }
  for (const cid in byClient) {
    const rows = byClient[cid].sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
    // PRIMARY renders (a fresh generate) OWN the numbers: a stamped params.seq is
    // permanent, older un-stamped primaries fill the gaps in creation order. A
    // re-render (Export Low/Full Rez → params.rerenderOf) INHERITS its source's
    // number so the high-rez export shares the draft's ### and only adds "HR".
    const claimed = new Set();
    const primaries = rows.filter((r) => !r.params?.rerenderOf);
    for (const r of primaries) { const s = Number(r.params?.seq); if (Number.isFinite(s)) { seqMap.set(r.id, s); claimed.add(s); } }
    let next = 1;
    for (const r of primaries) {
      if (!seqMap.has(r.id)) { while (claimed.has(next)) next++; seqMap.set(r.id, next); claimed.add(next); next++; }
    }
    for (const r of rows) {                 // re-renders inherit their source's number
      if (seqMap.has(r.id)) continue;
      const srcId = r.params?.rerenderOf;
      if (srcId && seqMap.has(srcId)) seqMap.set(r.id, seqMap.get(srcId));
      else { while (claimed.has(next)) next++; seqMap.set(r.id, next); claimed.add(next); next++; }
    }
    for (const r of rows) {                 // version, creation order, per variant
      const vk = `${cid}|${r.style}|${r.params?.photoSpec || ''}|${r.params?.album || ''}`;
      perVariant[vk] = (perVariant[vk] || 0) + 1;
      verMap.set(r.id, perVariant[vk]);
    }
  }
  // A render's NAME follows through a re-render chain rather than being copied
  // into it. An Export Full Rez is the same piece of work as the draft it came
  // from — same number, plus "HR" — so renaming the draft has to rename its
  // exports too. Copying the label at export time would freeze it and the two
  // files would drift apart the first time the name was corrected. An export
  // that was renamed on its own still wins, because its own label is checked
  // first.
  const paramsById = new Map((data || []).map((r) => [r.id, r.params || {}]));
  const labelFor = (m) => {
    let cur = m.params || {}, hops = 0;
    while (hops < 8) {
      if (typeof cur.label === 'string' && cur.label.trim()) return cur.label.trim();
      const src = cur.rerenderOf && paramsById.get(cur.rerenderOf);
      if (!src) return null;
      cur = src; hops++;
    }
    return null;
  };

  const STYLE_LABELS = { hollywood: 'Hollywood', timeless: 'Timeless', party: 'Party', party2: 'Party2', duotone: 'Duotone', duotone_pastel: 'DuotonePastel', duotone2: 'Duotone2', polaroid: 'PolaroidDrop', photo_drop: 'PhotoDrop', collage_classic: 'CollageClassic', collage_featured: 'CollageFeatured', gallery150: 'Gallery', epic_vintage: 'EpicVintage', story_builder: 'StoryBuilder', trendy: 'Trendy', multi_page: 'MultiPage', multi_page_record: 'MultiPageRecord', two_panel: 'TwoPanel', photo_slide: 'PhotoSlide', sliding_images: 'SlidingImages', photo_ribbon: 'PhotoRibbon', neon_frame: 'NeonFrame', comic_book: 'ComicBook', party3: 'Party3', basic_cut: 'BasicCut', framed_box: 'FramedBox' };
  const cp = (s) => String(s || '').replace(/[^A-Za-z0-9]+/g, '');
  // The number prefix: ### for a low-rez/draft, ###HR for a full-rez export — same
  // number, so a high-rez file sorts right next to the draft it came from.
  const seqLabel = (m) => String(seqMap.get(m.id) || 1).padStart(3, '0') + (m.watermarked ? '' : 'HR');
  // Strip only what a filesystem actually objects to, and collapse runs of
  // whitespace. Spaces are kept: the studio names these things in plain English
  // ("001HR_The New Taylors Name") and mangling that into TheNewTaylorsName
  // would defeat the point of being able to name them.
  const safeName = (v) => String(v || '')
    // Whitespace is collapsed FIRST: tabs and newlines are control characters,
    // so stripping those first would turn "A<tab>B" into "AB" rather than "A B".
    .replace(/\s+/g, ' ')
    .replace(/[\\/:*?"<>|\u0000-\u001f]+/g, '')
    .trim()
    .slice(0, 60);
  const renderName = (m) => {
    const num = seqLabel(m);
    // A named render is called by its name. Only an unnamed one falls back to the
    // descriptive form, which is what every render used to get.
    const named = safeName(labelFor(m));
    if (named) return `${num}_${named}.mp4`;
    const last = cp(m.studio_clients?.last_name || m.studio_clients?.display_name) || 'Client';
    const style = STYLE_LABELS[m.style] || cp(m.style) || 'Montage';
    const album = cp(m.params?.album);
    const range = String(m.params?.photoSpec || '').replace(/\s+/g, '').replace(/[^0-9,\-]/g, '') || 'all';
    const date = (m.created_at || '').slice(0, 10) || 'nodate';
    return [num, last, style, album, range, date].filter(Boolean).join('_') + `_V${verMap.get(m.id) || 1}.mp4`;
  };

  const montages = await Promise.all(
    (data || []).map(async (m) => ({
      id: m.id,
      seq: seqLabel(m),                  // ### for a draft, ###HR for a full-rez export
      version: verMap.get(m.id) || 1,
      name: renderName(m),               // full studio file name (###_Last_Style_Album_Range_Date_V#.mp4)
      album: m.params?.album || null,    // album this render was built from (if any)
      clientId: m.client_id,
      client: m.studio_clients?.display_name || '—',
      style: m.style,
      title: m.title,
      // A nickname the admin typed for this render; the list shows it instead of
      // the title card text so repeat attempts are tellable apart.
      label: labelFor(m),
      subtitle: m.subtitle,
      photoSeconds: m.params?.photoSeconds || null,
      adjustments: m.params?.adjustments || {},
      photoSpec: m.params?.photoSpec || null,
      includeCards: m.params?.includeCards !== false,
      greenScreen: m.params?.greenScreen !== false,
      hidden: m.params?.hidden === true,
      viewed: m.params?.viewed === true,
      starred: m.params?.starred === true,
      status: m.status,
      error: m.error,
      photoCount: m.photo_count,
      watermarked: m.watermarked,
      createdAt: m.created_at,
      // Prefer our permanent R2 copy; fall back to Creatomate's temp URL.
      url: m.r2_key ? await getViewUrl(m.r2_key, 3600) : m.video_url || null,
      // Force-download URL (Content-Disposition: attachment) so "Download MP4"
      // saves to a folder instead of navigating to the video (cross-origin
      // `download` is ignored by browsers). Only available for our R2 copies.
      downloadUrl: m.r2_key
        ? await getDownloadUrl(m.r2_key, renderName(m), 3600)
        : null,
      archived: !!m.r2_key, // false = still only on Creatomate's 30-day hosting
    }))
  );
  return NextResponse.json({ montages });
}


// ── MEVID STILLS helpers (9/9) ────────────────────────────────────────────
// Segment settings from the admin: transition order, screens, per-photo picks,
// manual groups. Kept small and validated — it is snapshotted into params.
function cleanStills(s) {
  if (!s || typeof s !== 'object') return null;
  const out = {};
  out.mode = ['cycle', 'shuffle', 'mix'].includes(s.mode) ? s.mode : 'cycle';
  out.mix = Array.isArray(s.mix) ? s.mix.filter((k) => typeof k === 'string' && /^[A-Za-z0-9_-]{1,32}$/.test(k)).slice(0, 40) : [];
  out.screens = ['off', 'auto', 'manual'].includes(s.screens) ? s.screens : 'off';
  out.shadow = s.shadow !== false;
  out.picks = {};
  if (s.picks && typeof s.picks === 'object') {
    for (const [k, v] of Object.entries(s.picks)) {
      if (typeof k === 'string' && k.length < 400 && typeof v === 'string' && /^[A-Za-z0-9_-]{1,32}$/.test(v)) out.picks[k] = v;
    }
  }
  out.groups = (Array.isArray(s.groups) ? s.groups : []).map((g) => {
    const keys = Array.isArray(g?.keys) ? g.keys.filter((k) => typeof k === 'string' && k.length < 400).slice(0, 4) : [];
    if (keys.length < 2) return null;
    return { keys, layout: typeof g.layout === 'string' && /^[a-z0-9_-]{1,24}$/i.test(g.layout) ? g.layout : null };
  }).filter(Boolean).slice(0, 200);
  if (Number.isFinite(Number(s.seed))) out.seed = Number(s.seed);
  return out;
}

// Presign a photo's cut-out / watercolor (made by stills-derive) onto the item.
async function attachStillsDerivatives(it, pePhotos) {
  const e = pePhotos && it.sourceKey ? pePhotos[it.sourceKey] : null;
  const d = e && e.stills && typeof e.stills === 'object' ? e.stills : null;
  if (!d) return;
  try { if (d.cutout_key && d.cutout_status !== 'failed') it.cutout_url = await getViewUrl(d.cutout_key, 21600); } catch { /* fallback move */ }
  try { if (d.watercolor_key && d.watercolor_status !== 'failed') it.watercolor_url = await getViewUrl(d.watercolor_key, 21600); } catch { /* fallback move */ }
}
